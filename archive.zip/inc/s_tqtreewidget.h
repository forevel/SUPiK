#ifndef S_TQTREEWIDGET_H
#define S_TQTREEWIDGET_H

#include <QTreeWidget>
#include <QHeaderView>

class s_tqTreeWidget : public QTreeWidget
{
    Q_OBJECT
public:
    explicit s_tqTreeWidget(QWidget *parent = 0);

signals:

public slots:

};

#endif // S_TQTREEWIDGET_H
