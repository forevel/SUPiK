#include "../inc/s_dlgeditdialog.h"

s_dlgeditdialog::s_dlgeditdialog(QWidget *parent) :
    QDialog(parent)
{
}
