#ifndef S_DLGEDITDIALOG_H
#define S_DLGEDITDIALOG_H

#include <QDialog>

class s_dlgeditdialog : public QDialog
{
    Q_OBJECT
public:
    explicit s_dlgeditdialog(QWidget *parent = 0);

signals:

public slots:

};

#endif // S_DLGEDITDIALOG_H
