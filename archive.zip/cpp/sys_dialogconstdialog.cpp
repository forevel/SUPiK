#include "../inc/sys_dialogconstdialog.h"

sys_dialogconstdialog::sys_dialogconstdialog(QWidget *parent) :
    QDialog(parent)
{
}

/*sys_dialogconstdialog::sys_dialogconstdialog(QString dialog, QWidget *parent) :
    QDialog(parent)
{

}*/

// ########################## МЕТОДЫ CONSTRITEM ###############################

/*int constritem::AddItem(int floc, int fname, int ftype, int ltype, int relfnum, QString link, bool isKeyField)
{

}

int constritem::DeleteItem(int fnum)
{

}
*/
